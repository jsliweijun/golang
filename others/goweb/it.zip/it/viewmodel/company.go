package viewModel

// Company
type Company struct {
	ID       string
	Name     string
	NickName string
}
