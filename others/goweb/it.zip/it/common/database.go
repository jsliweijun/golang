package common

import "database/sql"

// Db ...
var Db *sql.DB
