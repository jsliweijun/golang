package funcs

// Add ..
func Add(n1, n2 int) int {
	return n1 + n2
}
