package controller

// RegisterRoutes ...
func RegisterRoutes() {
	registerRoutes()
	registerAPIRoutes()
}
